spark-submit --master local[*] --class "edu.mit.csail.db.ml.modeldb.evaluation.Evaluate" target/scala-2.11/ml.jar $@
