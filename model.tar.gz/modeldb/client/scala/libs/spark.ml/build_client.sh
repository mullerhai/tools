../../../../scripts/gen_thrift_file.sh scala '../../../../thrift/ModelDB.thrift' './src/main/thrift/' 
sbt clean && sbt assembly