cd codegen && ./gen_sqlite.sh && cd .. && ./start_server.sh
