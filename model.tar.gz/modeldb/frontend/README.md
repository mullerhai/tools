## Setup

Make sure the ModelDB server is running, following the instructions in the server/ directory. 

Start the frontend from the frontend dir with:

    $ ./start_frontend.sh


Visit application at http://localhost:3000/projects
